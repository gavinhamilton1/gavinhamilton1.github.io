#!/bin/bash
name="Ali"
echo "Hello $name, have a nice day!"
