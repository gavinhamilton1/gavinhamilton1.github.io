#!/bin/bash
echo "Who is there?"
read name
echo "Hello $name, have a nice day!"
