#!/bin/bash
echo "Hello $1, have a nice day!"
