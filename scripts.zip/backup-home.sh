#!/bin/bash

backupdirs="/c/Users/gavin/Music /c/Users/gavin/Videos"
today=$(date -I)
zipfilename="home-$today-archive.zip"
#echo $filename
zip -r $zipfilename $backupdirs

