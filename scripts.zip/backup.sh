#!/bin/bash

srcdir="work"
today=$(date -I)
zipfilename="$srcdir-$today"
#echo $filename
zip -r $zipfilename-archive.zip $srcdir

